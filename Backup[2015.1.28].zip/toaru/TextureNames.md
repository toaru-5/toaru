﻿# 各テクスチャの名称
---
##### 日本語名/テクスチャのファイル名/追加したか(Y/N)
- 学習装置/LearningDevice.png/Y
- 液体窒素缶/LiquidNitrogenCan.png/Y/Y
- 圧縮された缶/CompressedAir.png/Y
- 鉄釘/IronNails.png/Y
- リモコン/Remote.png/Y
- アクセラステッキ/AxelaStick.png/Y
- 電磁波ゴーグルoff/ElectroMagneticWaveGoggles_off.png/Y/N
- 電磁波ゴーグルon/ElectroMagneticWaveGoggles_on.png/Y/N
- サイボーグハンド/CyborgHand.png/Y
- 電極/Electrode.png/Y
- ツリーダイヤグラムの破片/Treediagram_Debris.png/Y
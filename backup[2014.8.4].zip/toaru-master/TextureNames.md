﻿# 各テクスチャの名称
---
##### 日本語名/テクスチャのファイル名/追加したか(Y/N)
- 学習装置/LearningDevice.png/Y
- 液体窒素缶/LiquidNitrogenCan.png/Y/Y
- 圧縮された缶/CompressedAir.png/Y
- 鉄釘/IronNails.png/Y
- リモコン/Remote.png/N
- アクセラステッキ/AxelaStick.png/N
- 電磁波ゴーグルoff/ElectroMagneticWaveGoggles_off.png/N
- 電磁波ゴーグルon/ElectroMagneticWaveGoggles_on.png/N
- サイボーグハンド/CyborgHand.png/Y
- 電極/Electrode.png/Y